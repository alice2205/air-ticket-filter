// фильтрация по чекбоксам

const check = document.querySelector("#check-1");
console.log(check);

check.onclick = function (event) {
  console.log(check.checked);
  const isCheck = check.checked;
};

//фильтрация

// const filter = document.querySelectorAll(".price");

// document.querySelector("nav").addEventListener("click", (event) => {
//   if (event.target.tagName !== "P") return false;

//   let filterClass = event.target.dataset["f"];

//   filter.forEach((elem) => {
//     if (!elem.classList.contains(filterClass)) {
//       elem.classList.add("hide");
//     }
//   });
// });

function app() {
  const buttons = document.querySelectorAll(".ticket");
  const cards = document.querySelectorAll(".price");

  const cardsArr = [];
  cards.forEach(function (item) {
    cardsArr.push(item.innerHTML);
  });

  const cardsNumber = cardsArr.map(function (item) {
    return parseInt(item, 10);
  });

  function filter() {
    let result = cardsNumber.filter(function (item) {
      const filterCheap = Math.min.apply(Math, cardsNumber);
      if (item === filterCheap) {
        return true;
      } else {
        console.log(cards);
        console.log(item);
        cards[item].style.display = "none";
        // const deleted = document.querySelector(".ticket-card");
        // deleted.style.display = "none";
        // false;
      }
    });
    console.log(result);
  }

  // if (item != filterCheap) {
  //       for (let i = 0; i < cardsNumber.length; i++) {
  //         cardsNumber[i].classList.add("someClass");
  //         console.log(cardsNumber[i].classList);
  //       }
  // }

  buttons.forEach((button) => {
    button.addEventListener("click", filter);
  });
}

app();
